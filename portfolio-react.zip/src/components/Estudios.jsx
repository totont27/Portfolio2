import React from 'react';

const Estudios = () => (
  <section id="estudios">
    <h2>Estudios</h2>
    <p>Secundario completo en Colegio Nuestra Señora del Valle.</p>
    <p>Actualmente cursando la Tecnicatura Universitaria en Programación.</p>
  </section>
);

export default Estudios;

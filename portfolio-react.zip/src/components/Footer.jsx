import React from 'react';

const Footer = () => (
  <footer>
    <p>Redes Sociales:</p>
    <a href="https://github.com/tu_usuario" target="_blank" rel="noopener noreferrer">GitHub</a> |{' '}
    <a href="https://linkedin.com/in/tu_usuario" target="_blank" rel="noopener noreferrer">LinkedIn</a>
  </footer>
);

export default Footer;

import React from 'react';
import '../styles/App.css';

const Header = () => {
  return (
    <header className="header">
      <img src="/portada.jpg" alt="Mi foto de portada" className="portada" />
      <h1>Augusto Nicolás Tula</h1>
    </header>
  );
};

export default Header;

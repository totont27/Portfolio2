import React from 'react';
import Estudios from './Estudios';
import SoftSkills from './SoftSkills';

const Main = () => {
  const proyectos = [
    { nombre: 'App de Tareas', descripcion: 'CRUD con React y Zustand' },
    { nombre: 'Clon de Google', descripcion: 'Búsqueda y diseño con Vite + React Router' },
  ];

  const experiencia = [
    { puesto: 'Soporte Técnico', empresa: 'Freelance', año: '2023' },
  ];

  const idiomas = ['Español (nativo)', 'Inglés (básico escrito)'];

  const certificados = ['Curso de Git y GitHub - Udemy', 'Curso de React Básico - YouTube'];

  return (
    <main>
      <div id="presentacion">
        <p>Soy Augusto Nicolás Tula, estudiante de Programación en la Facultad Regional Tucumán...</p>
      </div>

      <Estudios />
      <SoftSkills />

      <section id="proyectos">
        <h2>Proyectos Realizados</h2>
        <ul>
          {proyectos.map((proy, i) => (
            <li key={i}><strong>{proy.nombre}</strong>: {proy.descripcion}</li>
          ))}
        </ul>
      </section>

      <section id="experiencia">
        <h2>Experiencia Laboral</h2>
        <ul>
          {experiencia.map((exp, i) => (
            <li key={i}>{exp.puesto} - {exp.empresa} ({exp.año})</li>
          ))}
        </ul>
      </section>

      <section id="idiomas">
        <h2>Idiomas</h2>
        <ul>
          {idiomas.map((idioma, i) => (
            <li key={i}>{idioma}</li>
          ))}
        </ul>
      </section>

      <section id="certificados">
        <h2>Certificados</h2>
        <ul>
          {certificados.map((cert, i) => (
            <li key={i}>{cert}</li>
          ))}
        </ul>
      </section>
    </main>
  );
};

export default Main;
